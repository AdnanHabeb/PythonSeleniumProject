import os

from dotenv import load_dotenv
from selenium.webdriver.common.by import By

from gui_base.base_element import BaseElement

load_dotenv(dotenv_path='.env')


class LoginPage(BaseElement):
    LOGIN_WRAPPER_LOCATOR = (By.ID, 'login_button_container')
    USERNAME = (By.ID, 'user-name')
    PASSWORD = (By.ID, 'password')
    LOGIN_BUTTON = (By.ID, 'login-button')

    def __init__(self, driver):
        super().__init__(driver)
        self.wait_for_page_to_load()

    def wait_for_page_to_load(self) -> None:
        """ Waiting for the login page to load """
        self.wait_for_visibility(by_locator=self.LOGIN_WRAPPER_LOCATOR)

    def fill_username(self, username: str) -> None:
        self.send_keys(by_locator=self.USERNAME, value=username)

    def fill_password(self, password: str) -> None:
        self.send_keys(by_locator=self.PASSWORD, value=password)

    def click_login(self) -> None:
        self.click(by_locator=self.LOGIN_BUTTON)

    def login(self, username: str = None, password: str = None):
        if username is None and password is None:
            username = os.environ.get('STANDARD_USERNAME')
            password = os.environ.get('PASSWORD')

        self.fill_username(username)
        self.fill_password(password)
        self.click_login()