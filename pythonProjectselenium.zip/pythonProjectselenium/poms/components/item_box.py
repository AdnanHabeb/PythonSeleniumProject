from selenium.webdriver.common.by import By
from selenium.webdriver.ie.webdriver import WebDriver
from selenium.webdriver.support import expected_conditions

from gui_base.base_element import BaseElement


class ItemBox(BaseElement):
    # Locator
    INVENTORY_ITEMS_LOCATOR = (By.CLASS_NAME, 'inventory_item')

    # Elements
    PRICE = 'inventory_item_price'
    DESCRIPTION = 'inventory_item_desc'
    ADD_TO_CART = 'btn_inventory'

    def __init__(self, driver: WebDriver, item_name):
        super().__init__(driver)
        self.item_name = item_name
        self.item = self.find_item()

    def find_item(self):
        all_items = self.wait.until(
            expected_conditions.visibility_of_all_elements_located(self.INVENTORY_ITEMS_LOCATOR))
        for item in all_items:
            if self.item_name in item.text:
                return item

    @property
    def price(self) -> str:
        return self.item.find_element_by_class_name(self.PRICE).text

    @property
    def description(self) -> str:
        return self.item.find_element_by_class_name(self.DESCRIPTION).text

    def add_to_cart(self) -> None:
        return self.item.find_element_by_class_name(self.ADD_TO_CART).click()