## local-environment
pre-requisites:
1. python 3.9 
1. [pipenv](https://github.com/pypa/pipenv#installation)
2. browser (google-chrome, etc...)
3. webdriver (chrome, etc...) should be in PATH environment variable


local-install:
- pipenv sync 

run the tests:
- python -m pytest 