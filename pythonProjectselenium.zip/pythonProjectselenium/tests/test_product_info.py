import time

import pytest

from poms.components.item_box import ItemBox
from poms.pages.login_page import LoginPage


class TestProductInfo:

    @pytest.fixture(autouse=True)
    def login(self, open_browser):
        login_page = LoginPage(open_browser)
        login_page.login()

    def test_product_info(self, open_browser):
        item_box = ItemBox(open_browser, 'Sauce Labs Bike Light')

        print('\n price: ', item_box.price)
        print('\n description: ', item_box.description)

        item_box.add_to_cart()
        time.sleep(2)
